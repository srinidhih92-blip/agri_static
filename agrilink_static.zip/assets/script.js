
// Small JS to toggle mobile nav on each page. Works without build tools.
function setupNav(toggleId, linksId){
  var t = document.getElementById(toggleId);
  var links = document.getElementById(linksId);
  if (!t || !links) return;
  t.addEventListener('click', function(){
    links.classList.toggle('show');
  });
  // close when clicking outside
  document.addEventListener('click', function(e){
    if (!t.contains(e.target) && !links.contains(e.target)){
      links.classList.remove('show');
    }
  });
}
// try to attach for possible ids on each page
setupNav('navToggle','navLinks');
setupNav('navToggleFarmer','navLinksFarmer');
setupNav('navToggleLabour','navLinksLabour');
setupNav('navToggleMach','navLinksMach');
